import subprocess
import getpass
#Mensaje de bienvenida
Contra= "ASDFQWER1234"

print("Hola!! Bienvenido a tu consulta de salario, Dime, ¿Que puesto tienes?")

#Declaracion de la funcion global
def seleccion_de_puesto():
    print("1)Gerente\n2)Coordinador\n3)Obrero..... \n(Selecciona tu puesto correspondiente)")
    puesto=input().upper()
    
#CONDICIONAL DE PUESTO SELECCIONADO (LEE Y VALIDA EL PUESTO INGRESADO)
    if puesto != "GERENTE" and puesto != "OBRERO" and puesto != "COORDINADOR":
        print("\nELIJA UNA OPCION VALIDA POR FAVOR!!!\n")
        seleccion_de_puesto()
        
#MENSAJE DE CONFIRMACION
    else:
        print("\nTu puesto es "+puesto+"\n¿Es correcto ese dato?(Y/N)")
        conf=input().upper()
        bkup= open('backup.txt','a')

#CONDICION EN CASO DE HABER CONFIRMADO PUESTO
        if conf == "Y":
            #gennera e inicializa los datos del trabajador
            nombre = input("INGRESE SU NOMBRE POR FAVOR: ").upper()
            apellidos = input("INGRESE APELLIDOS POR FAVOR: ").upper()
            correo = str(nombre[0]).lower() + str(apellidos[0:3]).lower() + "@hola.com"
            print("Tu correo es: "+correo)
            #esta funcion permite al usuario decidir si quedarse con contraseña provisional o cambiarla
            def confirma():
                conf=input().upper()
                #condicion en caso de mantener contraseña provisional
                if conf =="M":
                    print("Tu contraseña será: "+Contra)
                    print("\nPara obtener su estado de cuenta, por favor, ingrese su correo y contraseña\n")
                #EN ESTA PARTE, EL USUARIO PIDE ENTRAR AL SISTEMA Y SE VALIDA SU USUARIO Y CONTRASEÑA
                    def logueo():
                        corr = input("Correo: \n")
                        print("Contraseña: ")
                        con = getpass.getpass() #ESTA FUNCION DE LA LIBRERIA GETPASS IMPIDE QUE LA CONTRASEÑA SE IMPRIMA EN PANTALLA
                        if corr != correo or con != Contra:
                            print("Datos invalidos, favor de verificar")
                            logueo()
                        else:
                            print("Usted ha ingresado exitosamente")
                #FUNCION EN CASO DE QUE SE ELIJA CAMBIAR LA CONTRASEÑA
                elif conf=="C":
                    def nueva():
                        Contra= "ASDFQWER1234"
                        print("Ingresa tu contraseña anterior: ")
                        cambio=getpass.getpass()
                        if cambio =="ASDFQWER1234":
                            print("Ingresa tu nueva contraseña: ")
                            nuevaCont=getpass.getpass()
                            if len(nuevaCont) < 8 :
                                print("ingresa una contraseña con mas de 8 caracteres")
                                nueva()
                            else:
                                print("Confirma Contraseña nueva: ")
                                verconnu = getpass.getpass()
                                if verconnu != nuevaCont:
                                        print("Los datos no coinciden, verifique nuevamente")
                                        nueva()  
                                else:
                                    print("Has cambiado tu contraseña con exito")
                                    Contra= nuevaCont
                                    print(Contra[-3:-1]+Contra[-1]) 
                                    print("\nPara obtener su estado de cuenta, por favor, ingrese su correo y contraseña\n")
                                    def logueo():
                                        corr = input ("Correo: ")
                                        con = getpass.getpass()
                                        if corr != correo or con != Contra:
                                            print("Datos invalidos, favor de verificar")
                                            logueo()
                                    logueo()
                        else:
                            print("Contraseña Inválida")
                            nueva()
                    nueva()
                else:
                    print("Ingresa una opcion válida")
                    confirma()
         
#INGRESA DATOS DE EMPLEADO

            if puesto == "GERENTE":
   
                salario_inicial = 24000
                SegSoc= salario_inicial * 0.062
                IVA=salario_inicial * 0.16
                ifv = input("¿Cuenta con infonavit? (Y/N) ").upper()
                
                if ifv == "Y":
                    print("Tu contraseña es:  " + Contra)
                    print("¿Gustas mantenerla o cambiarla? (M/C)")
                    confirma()
                    nc=Contra[-3:-1]+Contra[-1]

                    #DESGLOSE DE SALARIO, IMPUESTOS Y OTRAS PRESTACIONES SI CUENTA CON INFONAVIT
                    Infonavit= salario_inicial * 0.05
                    salario_final = salario_inicial -SegSoc - Infonavit- IVA 
                    
                    print("\n\nTus datos son :\nNombre: "+nombre+"\nApellidos: "+apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial))
                    print("Tu correo es: "+correo)
                   # print("Contraseña: "+"******" + nc)
                    print("Tu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc))
                    print("Tu descuento de vivienda : "+"$"+str(Infonavit))
                    print("IVA: "+str(IVA))
                    print ("Tu nuevo salario neto mensual es de: "+ "$"+str(salario_final))
                    bkup.write(
                    "----------------------------------------------------------------------------"
                    "\nTus datos son :\nNombre: "+nombre+"\nApellidos: "+apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial)
                    +"\nTu correo es: "+correo+
                    #"\nContraseña: "+nc+
                    "\nTu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc)+
                    "\nTu descuento de vivienda : "+"$"+str(Infonavit)+
                    "\nIVA: "+str(IVA)+
                    "\nTu nuevo salario neto mensual es de: "+"$"+ str(salario_final)
                    +"\n---------------------------------------------------------------------------\n"
                    )
                else:
                    print("Tu contraseña es:  " + Contra)
                    print("¿Gustas mantenerla o cambiarla? (M/C)")
                    confirma()
                    #DESGLOSE DE SALARIO, IMPUESTOS Y OTRAS PRESTACIONES SI NO CUENTA CON INFONAVIT
                    salario_final = salario_inicial -SegSoc -  IVA 
                    correo = str(nombre[0]).lower() + str(apellidos[0:3]).lower() + "@hola.com"
                    print("\n\nTus datos son :\nNombre: "+nombre+"\nApellidos: "+apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial))
                    print("Tu correo es: "+correo)
                    #print("Contraseña: "+"******" +nc)
                    print("Tu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc))
                    print("IVA: "+str(IVA))
                    print ("Tu nuevo salario neto mensual es de: "+"$"+ str(salario_final))
                    bkup.write(
                    "----------------------------------------------------------------------------"
                    "\nTus datos son :\nNombre: "+nombre+"\nApellidos: "+apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial)
                    +"\nTu correo es: "+correo+
                    #"\nContraseña: "+nc+
                    "\nTu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc)+
                    "\nIVA: "+str(IVA)+
                    "\nTu nuevo salario neto mensual es de: "+"$"+ str(salario_final)
                    +"\n---------------------------------------------------------------------------\n"
                    )
                    
            #INGRESA DATOS DE EMPLEADO
            elif puesto == "COORDINADOR":
                salario_inicial = 15000
                SegSoc= salario_inicial * 0.062
                IVA=salario_inicial * 0.16
                ifv = input("¿Cuenta con infonavit? (Y/N) ").upper()
                
                if ifv == "Y":
                    print("Tu contraseña es:  " + Contra)
                    print("¿Gustas mantenerla o cambiarla? (M/C)")
                    confirma()
                    
                    #DESGLOSE DE SALARIO, IMPUESTOS Y OTRAS PRESTACIONES SI CUENTA CON INFONAVIT
                    Infonavit= salario_inicial * 0.05
                    salario_final = salario_inicial -SegSoc - Infonavit- IVA 
                    correo = str(nombre[0]).lower() + str(apellidos[0:3]).lower() + "@hola.com"

                    print("\n\nTus datos son :\nNombre: "+nombre+"\nApellidos: "+apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial))
                    print("Tu correo es: "+correo)
                    #print("Contraseña: "+"******" +nc)
                    print("Tu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc))
                    print("Tu descuento de vivienda : "+"$"+str(Infonavit))
                    print("IVA: "+str(IVA))
                    print ("Tu nuevo salario neto mensual es de: "+"$"+ str(salario_final))
                    bkup.write(
                    "----------------------------------------------------------------------------"
                    "\nTus datos son :\nNombre: "+nombre+"\nApellidos: "+apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial)
                    +"\nTu correo es: "+correo+
                    #"\nContraseña: "+nc+
                    "\nTu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc)+
                    "\nTu descuento de vivienda : "+"$"+str(Infonavit)+
                    "\nIVA: "+str(IVA)+
                    "\nTu nuevo salario neto mensual es de: "+"$"+ str(salario_final)
                    +"\n---------------------------------------------------------------------------\n"
                    )
                else:
                    print("Tu contraseña es:  " + Contra)
                    print("¿Gustas mantenerla o cambiarla? (M/C)")
                    confirma()
                    #DESGLOSE DE SALARIO, IMPUESTOS Y OTRAS PRESTACIONES SI NO CUENTA CON INFONAVIT
                    salario_final = salario_inicial -SegSoc -  IVA 
                    correo = str(nombre[0]).lower() + str(apellidos[0:3]).lower() + "@hola.com"
                    print("\n\nTus datos son :\nNombre: "+nombre+"\nApellidos: "+apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial))
                    print("Tu correo es: "+correo)
                    #print("Contraseña: "+"******" +nc)
                    print("Tu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc))
                    print("IVA: "+str(IVA))
                    print ("Tu nuevo salario neto mensual es de: "+"$"+ str(salario_final))
                    bkup.write(
                    "----------------------------------------------------------------------------"
                    "\nTus datos son :\nNombre: "+nombre+"\nApellidos: "+apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial)
                    +"\nTu correo es: "+correo+
                    #"\nContraseña: "+nc+
                    "\nTu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc)+
                    "\nIVA: "+str(IVA)+
                    "\nTu nuevo salario neto mensual es de: "+"$"+ str(salario_final)
                    +"\n---------------------------------------------------------------------------\n"
                    )
                    
            #INGRESA DATOS DE EMPLEADO
            elif puesto == "OBRERO":
                
                salario_inicial = 6000
                SegSoc= salario_inicial * 0.062
                IVA=salario_inicial * 0.16
                ifv = input("¿Cuenta con infonavit? (Y/N) ").upper()
                if ifv == "Y":
                    print("Tu contraseña es:  " + Contra)
                    print("¿Gustas mantenerla o cambiarla? (M/C)")
                    confirma()
                    #DESGLOSE DE SALARIO, IMPUESTOS Y OTRAS PRESTACIONES SI CUENTA CON INFONAVIT
                    Infonavit= salario_inicial * 0.05
                    salario_final = salario_inicial -SegSoc - Infonavit- IVA 
                    correo = str(nombre[0]).lower() + str(apellidos[0:3]).lower() + "@hola.com"

                    print("\n\nTus datos son :\nNombre: "+nombre+"\nApellidos: "+apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial))
                    print("Tu correo es: "+correo)
                    #print("Contraseña: "+"******" +nc)
                    print("Tu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc))
                    print("Tu descuento de vivienda : "+"$"+str(Infonavit))
                    print("IVA: "+str(IVA))
                    print ("Tu nuevo salario neto mensual es de: "+ "$"+str(salario_final))
                    bkup.write(
                    "----------------------------------------------------------------------------"
                    "\nTus datos son :\nNombre: "+nombre+"\nApellidos: "+apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial)
                    +"\nTu correo es: "+correo+
                    #"\nContraseña: "+nc+
                    "\nTu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc)+
                    "\nTu descuento de vivienda : "+"$"+str(Infonavit)+
                    "\nIVA: "+str(IVA)+
                    "\nTu nuevo salario neto mensual es de: "+"$"+ str(salario_final)
                    +"\n---------------------------------------------------------------------------\n"
                    )
                else:
                    print("Tu contraseña es:  " + Contra)
                    print("¿Gustas mantenerla o cambiarla? (M/C)")
                    confirma()
                    #DESGLOSE DE SALARIO, IMPUESTOS Y OTRAS PRESTACIONES SI NO CUENTA CON INFONAVIT
                    salario_final = salario_inicial -SegSoc -  IVA 
                    correo = str(nombre[0]).lower() + str(apellidos[0:3]).lower() + "@hola.com"

                    print("\n\nTus datos son :\nNombre: "+nombre+"\nApellidos: "+apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial))
                    print("Tu correo es: "+correo)
                    #print("Contraseña: "+"******" +nc)
                    print("Tu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc))
                    print("IVA: "+str(IVA))
                    print ("Tu nuevo salario neto mensual es de: "+"$"+ str(salario_final))
                    bkup.write(
                    "----------------------------------------------------------------------------"
                    "\nTus datos son :\nNombre: "+nombre+"\nApellidos: "+apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial)
                    +"\nTu correo es: "+correo+
                    # "\nContraseña: "+nc+
                    "\nTu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc)+
                    "\nIVA: "+str(IVA)+
                    "\nTu nuevo salario neto mensual es de: "+"$"+ str(salario_final)
                    +"\n---------------------------------------------------------------------------\n"
                    )
            
            #SI NO SE CUMPLE NINGUNA DE LAS CONDICIONES DE PUESTO
            else:
                print("INGRESE UNA OPCION VALIDA POR FAVOR")
                seleccion_de_puesto()
        
        #SI NO SE ESCRIBE CORRECTAMENTE EL PUESTO
        else:
            print("SELECCIONA TU PUESTO CORRECTAMENTE....")
            seleccion_de_puesto()

#INICIALIZA LA FUNCION GLOBAL
seleccion_de_puesto()